# Nigerian Money Tools

A free Nigerian loan and savings calculator website for GitHub Pages.

## Files
- `index.html` — loan calculator
- `savings.html` — savings calculator
- `style.css` — shared design
- `script.js` — loan calculator logic
- `savings.js` — savings calculator logic

## GitHub Pages
Upload/replace all files in the repository, commit the changes, and GitHub Pages will redeploy automatically from the `main` branch and root folder.

## Important
These calculators provide educational estimates only. Actual financial products can use different rates, fees, taxes and calculation methods.
