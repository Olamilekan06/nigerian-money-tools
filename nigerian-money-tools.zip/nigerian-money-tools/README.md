# Nigerian Money Tools

Free Nigerian loan calculator for GitHub Pages.

## Publish
1. Create a new GitHub repository named `nigerian-money-tools`.
2. Upload `index.html`, `style.css`, and `script.js`.
3. Open Settings -> Pages.
4. Under Build and deployment choose Deploy from a branch.
5. Choose `main` and `/ (root)`, then Save.
6. Open the GitHub Pages URL shown there.

The calculator is an estimate, not financial advice.
